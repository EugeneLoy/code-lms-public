"""
_tkinter WASM port — Python-side bridge to tcltk.wasm via the
_tkinter_wasm JS global object (defined in test.html).

Public interface mirrors the C extension module _tkinter from CPython 3.14.2:
  cpython/Modules/_tkinter.c
  cpython/Modules/clinic/_tkinter.c.h

All newly introduced names use the prefix "_tkinter_wasm" and carry a
# TKINTER-WASM: comment.  Changes to the public interface that differ from
the C module carry a # PORTING NOTE: comment.
"""

from __future__ import annotations

from typing import Any, Callable


# ---------------------------------------------------------------------------
# Version constants (str, from TK_VERSION / TCL_VERSION macros in tk.h/tcl.h)
# ---------------------------------------------------------------------------

TK_VERSION: str = "8.6"
TCL_VERSION: str = "8.6"

# ---------------------------------------------------------------------------
# Event-mask / file-handler constants  (tcl.h)
# ---------------------------------------------------------------------------

READABLE: int       = 2      # TCL_READABLE   (1<<1)
WRITABLE: int       = 4      # TCL_WRITABLE   (1<<2)
EXCEPTION: int      = 8      # TCL_EXCEPTION  (1<<3)

DONT_WAIT: int      = 2      # TCL_DONT_WAIT      (1<<1)
WINDOW_EVENTS: int  = 4      # TCL_WINDOW_EVENTS  (1<<2)
FILE_EVENTS: int    = 8      # TCL_FILE_EVENTS    (1<<3)
TIMER_EVENTS: int   = 16     # TCL_TIMER_EVENTS   (1<<4)
IDLE_EVENTS: int    = 32     # TCL_IDLE_EVENTS    (1<<5)
ALL_EVENTS: int     = ~DONT_WAIT  # TCL_ALL_EVENTS = ~TCL_DONT_WAIT = -3

# ---------------------------------------------------------------------------
# TclError
# ---------------------------------------------------------------------------

class TclError(Exception):
    """Exception raised by the Tcl interpreter."""


# ---------------------------------------------------------------------------
# Tcl_Obj  (_tkinter.Tcl_Obj)
#
# PORTING NOTE: In the C module, Tcl_Obj wraps a Tcl_Obj* and is
# DISALLOW_INSTANTIATION — user code cannot construct it directly.  In the
# WASM port we need to construct it internally, so we allow construction but
# only via the internal factory _tkinter_wasm_Tcl_Obj_new().  The class
# identity (isinstance checks in tkinter/__init__.py) is preserved.
# ---------------------------------------------------------------------------

class Tcl_Obj:
    """Python wrapper around a Tcl value (mirrors _tkinter.Tcl_Obj)."""

    # TKINTER-WASM: __slots__ keeps instances lightweight.
    __slots__ = ("_string", "_typename")

    # TKINTER-WASM: internal constructor flag — user code should not call
    # Tcl_Obj() directly; use _tkinter_wasm_Tcl_Obj_new() below.
    def __init__(self, string: str, typename: str = "string") -> None:
        # PORTING NOTE: C module disallows direct instantiation.  WASM port
        # allows it internally so the bridge can produce typed Tcl_Obj values.
        self._string = str(string)
        self._typename = str(typename)

    @property
    def typename(self) -> str:
        """Name of the Tcl internal type (e.g. 'int', 'list', 'dict')."""
        return self._typename

    @property
    def string(self) -> str:
        """The string representation of this object."""
        return self._string

    def __str__(self) -> str:
        return self._string

    def __repr__(self) -> str:
        return f"<Tcl_Obj {self._typename!r}: {self._string!r}>"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Tcl_Obj):
            return self._string == other._string
        if isinstance(other, str):
            return self._string == other
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._string)

    def __bool__(self) -> bool:
        # PORTING NOTE: The C module returns plain str("") for empty Tcl
        # results (FromObj typePtr==NULL → unicodeFromTclObj → "").  Our
        # bridge always wraps in Tcl_Obj, so Tcl_Obj("") must be falsy to
        # match the C truthiness contract used by _getints/._getdoubles/
        # _getboolean guards ("if string: ...") in tkinter/__init__.py.
        return self._string != ""


def _tkinter_wasm_Tcl_Obj_new(string: str, typename: str = "string") -> Tcl_Obj:
    # TKINTER-WASM: internal factory for Tcl_Obj instances.
    return Tcl_Obj(string, typename)


# ---------------------------------------------------------------------------
# tktimertoken  (_tkinter.TkttType)
# ---------------------------------------------------------------------------

class tktimertoken:
    """Token representing a pending Tcl timer callback."""

    # TKINTER-WASM: stores the JS timer id returned by setTimeout so that
    # deletetimerhandler() can cancel it.
    __slots__ = ("_timer_id", "_cancelled")

    def __init__(self, timer_id: Any) -> None:  # TKINTER-WASM
        self._timer_id = timer_id
        self._cancelled = False

    def deletetimerhandler(self) -> None:
        """Cancel the timer."""
        if not self._cancelled:
            self._cancelled = True
            try:
                from js import clearTimeout  # type: ignore[import]
                clearTimeout(self._timer_id)
            except Exception:
                pass  # PORTING TODO: log failure in debug mode


TkttType = tktimertoken


# ---------------------------------------------------------------------------
# _tkinter_wasm_create_proxy — wrap a Python callable for safe JS use
# TKINTER-WASM: Pyodide auto-destroys "borrowed" PyProxies at the end of a
# JS function call.  create_proxy() creates a persistent proxy that survives
# until .destroy() is called.  We keep a reference on the tkapp instance and
# destroy it in deletecommand.
# ---------------------------------------------------------------------------

def _tkinter_wasm_create_proxy(func: Callable) -> Any:  # TKINTER-WASM
    """Wrap *func* in a persistent PyProxy for passing to JS.

    Returns the original *func* if pyodide.ffi is not available (non-Pyodide).
    """
    try:
        from pyodide.ffi import create_proxy  # type: ignore[import]
        return create_proxy(func)
    except ImportError:
        return func


def _tkinter_wasm_destroy_proxy(proxy: Any) -> None:  # TKINTER-WASM
    """Destroy a proxy created by _tkinter_wasm_create_proxy."""
    if proxy is None:
        return
    try:
        proxy.destroy()
    except (AttributeError, Exception):
        pass


# ---------------------------------------------------------------------------
# _tkinter_wasm_eval — thin wrapper with TclError conversion
# TKINTER-WASM: All Tcl evaluation goes through this function so that JS
# errors from the bridge are converted to Python TclError uniformly.
# ---------------------------------------------------------------------------

def _tkinter_wasm_eval(script: str) -> str:  # TKINTER-WASM
    """Evaluate *script* in the Tcl interpreter; return result as str.
    Raises TclError on TCL_ERROR."""
    try:
        result = _tkinter_wasm.eval(script)
        return str(result) if result is not None else ""
    except Exception as exc:
        # JS Error from the bridge; message is the Tcl errorInfo string.
        raise TclError(str(exc)) from None


def _tkinter_wasm_quote(s: str) -> str:  # TKINTER-WASM
    """Brace-quote *s* for safe embedding in a Tcl script as one word."""
    return str(_tkinter_wasm._tclQuote(str(s)))


def _tkinter_wasm_to_tcl(value: Any) -> str:  # TKINTER-WASM
    """Convert a Python value to its Tcl string representation.

    Used by setvar/call to convert Python objects before passing to Tcl.
    Mirrors the AsObj() dispatch in _tkinter.c.
    """
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        # Tcl requires full precision; repr gives enough digits.
        return repr(value)
    if isinstance(value, bytes):
        # PORTING TODO: C uses Tcl_NewByteArrayObj; here we latin-1 decode
        # to preserve byte values as Tcl characters.  Full binary support
        # would require a proper bytearray Tcl type.
        return value.decode("latin-1")
    if isinstance(value, (list, tuple)):
        # Recursively build a Tcl list.
        return _tkinter_wasm_make_list(value)
    if isinstance(value, Tcl_Obj):
        return value.string
    if value is None:
        return ""
    return str(value)


def _tkinter_wasm_make_list(seq: Any) -> str:  # TKINTER-WASM
    """Build a Tcl list string from a Python sequence."""
    parts = []
    for item in seq:
        s = _tkinter_wasm_to_tcl(item)
        parts.append(_tkinter_wasm_quote(s))
    return " ".join(parts)


def _tkinter_wasm_from_tcl(result: str, wantobjects: int) -> Any:  # TKINTER-WASM
    """Convert a Tcl result string to a Python value.

    Mirrors the behaviour of Tkapp_ObjectResult / FromObj in _tkinter.c.

    wantobjects == 0
        Always returns str (unicodeFromTclObj path).

    wantobjects >= 1
        The C module type-dispatches on the Tcl internal type pointer.  The
        WASM bridge only has the string representation, so we mirror the most
        common paths:

        • Any string result → plain str(result).
          In C, Tcl string values (typePtr in {NULL, StringType,
          UTF32StringType, PixelType}) all return str via unicodeFromTclObj.
          These cover the overwhelming majority of widget call() results —
          text labels, item content, widget names, option values, etc.
          Empty string is naturally falsy, satisfying the `if string:` guards
          in tkinter/__init__.py's _getints/_getdoubles/_getboolean.

    PORTING NOTE: The C module also returns typed objects (int, float, bool,
    bytes, tuple) for values with matching Tcl internal types, and returns
    Tcl_Obj for unknown extension types.  Those paths are not replicated here:
    • Callers that need a specific type call getint()/getdouble()/getboolean()
      explicitly (all of which accept str input).
    • The Tcl_Obj fallback in C is only triggered for obscure extension-module
      types not present in standard Tcl/Tk usage.
    • isinstance(value, (str, _tkinter.Tcl_Obj)) checks in tkinter/__init__.py
      (_gridconvvalue etc.) accept plain str, so returning str is correct.

    Returning str rather than Tcl_Obj is essential for str.join() and other
    string operations that reject non-str sequence elements (e.g. Listbox.get()
    results used in ", ".join(items)).
    """
    if wantobjects == 0:
        return result
    # Return plain str for all results — matches C's dominant unicodeFromTclObj
    # path (NULL/StringType/UTF32StringType/PixelType all → str).
    return result


# ---------------------------------------------------------------------------
# Module-level quit flag  (mirrors C's static int quitMainLoop)
# TKINTER-WASM: quit() sets this to True; mainloop() checks and resets it.
# Module-level (not per-instance) so that quit() on any tkapp stops all
# running mainloop() calls, matching the C behaviour.
# ---------------------------------------------------------------------------

_tkinter_wasm_quit_main_loop: bool = False  # TKINTER-WASM


# ---------------------------------------------------------------------------
# tkapp  (_tkinter.TkappType)
# ---------------------------------------------------------------------------

class tkapp:
    """Tcl/Tk interpreter application object (_tkinter.tkapp).

    Instances are created via _tkinter.create(), not by calling this class
    directly.
    """

    # TKINTER-WASM: instance state
    __slots__ = (
        "_wantobjects",   # int: 0=str, 1=typed objects, 2=Tcl_Obj callbacks
        "_trace_func",    # Callable | None
        "_commands",      # dict[str, Callable] — Python-side command registry
        "_command_proxies",  # dict[str, Any] — PyProxy references (keep alive)
    )

    def __init__(self, wantobjects: int = 1) -> None:  # TKINTER-WASM
        self._wantobjects = wantobjects
        self._trace_func = None
        self._commands: dict[str, Callable] = {}
        self._command_proxies: dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _eval(self, script: str) -> str:  # TKINTER-WASM
        """Evaluate *script*; fire trace; return result str."""
        if self._trace_func is not None:
            try:
                self._trace_func((script,))
            except Exception:
                pass
        return _tkinter_wasm_eval(script)

    def _result(self, raw: str) -> Any:  # TKINTER-WASM
        """Apply wantobjects conversion to a raw Tcl result string."""
        return _tkinter_wasm_from_tcl(raw, self._wantobjects)

    def _drain(self) -> None:  # TKINTER-WASM
        """Drain pending Python callbacks from the Tcl callback queue."""
        _tkinter_wasm.drainCallbacks()

    # ------------------------------------------------------------------
    # Tcl command invocation
    # ------------------------------------------------------------------

    def call(self, *args: Any) -> Any:
        """Invoke a Tcl command.

        Accepts any number of positional arguments; a single tuple argument
        is unwrapped.  Returns the result as str (wantobjects=0) or a
        typed Python object (wantobjects>=1).  Raises TclError on failure.
        (Tkapp_Call, METH_VARARGS)
        """
        # Unwrap single-tuple argument (matches C behaviour).
        if len(args) == 1 and isinstance(args[0], (tuple, list)):
            args = tuple(args[0])

        # Build a Tcl command string from the arguments.
        parts = [_tkinter_wasm_quote(_tkinter_wasm_to_tcl(a)) for a in args]
        script = " ".join(parts)

        if self._trace_func is not None:
            try:
                self._trace_func(args)
            except Exception:
                pass

        raw = _tkinter_wasm_eval(script)
        self._drain()
        return self._result(raw)

    def eval(self, script: str) -> str:
        """Evaluate a Tcl script string; return the result as str.
        (clinic: eval($self, script: str, /) -> str)
        """
        # PORTING NOTE: C always returns str regardless of wantobjects.
        raw = self._eval(str(script))
        self._drain()
        return raw

    def evalfile(self, fileName: str) -> str:
        """Source and evaluate a Tcl file; return the result as str.
        (clinic: evalfile($self, fileName: str, /) -> str)
        """
        # PORTING TODO: Tcl's "source" command reads from the WASM VFS.
        # Files must be present in the Emscripten filesystem.
        raw = self._eval("source " + _tkinter_wasm_quote(str(fileName)))
        self._drain()
        return raw

    def record(self, script: str) -> str:
        """Record script in Tcl history without evaluating; return result.
        (clinic: record($self, script: str, /) -> str)

        PORTING NOTE: Tcl_RecordAndEval with TCL_NO_EVAL is not directly
        accessible via TkBrowserEval.  We fall back to a no-op (return empty
        string) since history recording is non-essential for widget operation.
        """
        # PORTING TODO: implement via Tcl history command if needed.
        return ""

    def adderrorinfo(self, msg: str) -> None:
        """Append msg to the Tcl error-info stack.
        (clinic: adderrorinfo($self, msg: str, /) -> None)
        """
        try:
            self._eval(
                "append ::errorInfo " + _tkinter_wasm_quote(str(msg))
            )
        except TclError:
            pass

    # ------------------------------------------------------------------
    # Variable access
    # ------------------------------------------------------------------

    def _varname(self, name: Any) -> str:  # TKINTER-WASM
        """Normalise a variable name argument to str."""
        if isinstance(name, Tcl_Obj):
            return name.string
        if isinstance(name, bytes):
            return name.decode("utf-8")
        return str(name)

    def setvar(self, name: Any, value: Any, *rest: Any) -> None:
        """Set Tcl variable *name* to *value*.

        Two-arg form:   setvar(name, value)
        Three-arg form: setvar(array, key, value)  — array element access.
        (Tkapp_SetVar, METH_VARARGS)
        """
        if rest:
            # Three-arg form: name=array, value=key, rest[0]=actual value
            array = self._varname(name)
            key = self._varname(value)
            actual = rest[0]
            script = (
                "set "
                + _tkinter_wasm_quote(array)
                + "("
                + _tkinter_wasm_quote(key)
                + ") "
                + _tkinter_wasm_quote(_tkinter_wasm_to_tcl(actual))
            )
        else:
            script = (
                "set "
                + _tkinter_wasm_quote(self._varname(name))
                + " "
                + _tkinter_wasm_quote(_tkinter_wasm_to_tcl(value))
            )
        self._eval(script)

    def globalsetvar(self, name: Any, value: Any, *rest: Any) -> None:
        """Like setvar() but operates in global (::) scope.
        (Tkapp_GlobalSetVar, METH_VARARGS)
        """
        # PORTING NOTE: tcltk.wasm always evaluates at global scope
        # (TCL_EVAL_GLOBAL in TkBrowserEval), so setvar and globalsetvar are
        # equivalent in this port.
        self.setvar(name, value, *rest)

    # TKINTER-WASM: sentinel object used to detect omitted optional arguments
    # in getvar/unsetvar.  Must be defined before the methods that reference it.
    _tkinter_wasm_sentinel = object()  # TKINTER-WASM

    def getvar(self, name: Any, index: Any = None) -> Any:
        """Get the value of Tcl variable *name*.

        Optional second arg *index* selects an array element.
        Returns str (wantobjects=0) or typed object (wantobjects>=1).
        Raises TclError if the variable does not exist.
        (Tkapp_GetVar, METH_VARARGS)
        """
        varname = self._varname(name)
        if index is not None:
            # Array element access: $name(index)
            varname = varname + "(" + self._varname(index) + ")"
        raw = self._eval("return $" + _tkinter_wasm_quote(varname))
        return self._result(raw)

    def globalgetvar(self, name: Any, index: Any = None) -> Any:
        """Like getvar() but reads from global scope.
        (Tkapp_GlobalGetVar, METH_VARARGS)
        """
        # PORTING NOTE: same as getvar() — TkBrowserEval is always global.
        if index is None:
            return self.getvar(name)
        return self.getvar(name, index)

    def unsetvar(self, name: str, index: str = None) -> None:  # type: ignore[assignment]
        """Unset Tcl variable *name* (optionally array element *index*).
        Note: C accepts only str (not bytes/Tcl_Obj) for name/index.
        (Tkapp_UnsetVar, METH_VARARGS; format "s|s")
        """
        varname = str(name)
        if index is not None:
            varname = varname + "(" + str(index) + ")"
        try:
            self._eval("unset " + _tkinter_wasm_quote(varname))
        except TclError as exc:
            raise TclError(str(exc)) from None

    def globalunsetvar(self, name: str, index: str = None) -> None:  # type: ignore[assignment]
        """Like unsetvar() but operates in global scope."""
        # PORTING NOTE: same as unsetvar() — TkBrowserEval is always global.
        self.unsetvar(name, index)

    # ------------------------------------------------------------------
    # Type conversion helpers
    # ------------------------------------------------------------------

    def getint(self, arg: Any) -> int:
        """Convert arg to a Python int via Tcl bignum machinery.
        (clinic: getint($self, arg: object, /) -> int)

        PORTING NOTE: The C module uses Tcl's bignum/wideInt path which parses
        decimal and 0x-prefixed hex integers (Tcl integer literal syntax).
        We replicate this: decimal strings use int(s), 0x/0X-prefixed strings
        use int(s, 16).  Python's int(s, 0) would also accept 0o octal and 0b
        binary, which Tcl does not, so we do not use base 0.
        """
        if isinstance(arg, bool):
            return int(arg)
        if isinstance(arg, int):
            return arg
        if isinstance(arg, Tcl_Obj):
            s = arg.string
        elif isinstance(arg, str):
            s = arg
        else:
            raise TclError(f"expected integer but got {type(arg).__name__!r}")
        s = s.strip()
        try:
            # Tcl accepts decimal integers and 0x hex; use int(s,0) only for
            # 0x prefix, plain int(s) otherwise to avoid octal/binary misparse.
            if s.startswith(("0x", "0X")):
                return int(s, 16)
            return int(s)
        except ValueError:
            raise TclError(f"expected integer but got {s!r}") from None

    def getdouble(self, arg: Any) -> float:
        """Convert arg to a Python float.
        (clinic: getdouble($self, arg: object, /) -> float)
        """
        if isinstance(arg, float):
            return arg
        if isinstance(arg, (int, bool)):
            return float(arg)
        if isinstance(arg, Tcl_Obj):
            s = arg.string
        elif isinstance(arg, str):
            s = arg
        else:
            raise TclError(f"expected floating-point number but got {type(arg).__name__!r}")
        try:
            return float(s)
        except ValueError:
            raise TclError(f"expected floating-point number but got {s!r}") from None

    def getboolean(self, arg: Any) -> bool:
        """Convert arg to a Python bool using Tcl boolean rules.
        (clinic: getboolean($self, arg: object, /) -> bool)

        Accepted true values:  1, true, yes, on  (case-insensitive)
        Accepted false values: 0, false, no, off  (case-insensitive)
        """
        if isinstance(arg, bool):
            return arg
        if isinstance(arg, int):
            return bool(arg)
        if isinstance(arg, Tcl_Obj):
            s = arg.string
        elif isinstance(arg, str):
            s = arg
        else:
            raise TclError(f"expected boolean value but got {type(arg).__name__!r}")
        s_lower = s.strip().lower()
        if s_lower in ("1", "true", "yes", "on"):
            return True
        if s_lower in ("0", "false", "no", "off"):
            return False
        raise TclError(f"expected boolean value but got {s!r}")

    # ------------------------------------------------------------------
    # Expression evaluation
    # ------------------------------------------------------------------

    def exprstring(self, s: str) -> str:
        """Evaluate Tcl expression *s* and return result as str.
        (clinic: exprstring($self, s: str, /) -> str)
        """
        return self._eval("expr " + _tkinter_wasm_quote(str(s)))

    def exprlong(self, s: str) -> int:
        """Evaluate Tcl expression *s* and return result as int.
        (clinic: exprlong($self, s: str, /) -> int)
        """
        raw = self._eval("expr " + _tkinter_wasm_quote(str(s)))
        try:
            return int(raw)
        except ValueError:
            raise TclError(f"expression result is not an integer: {raw!r}") from None

    def exprdouble(self, s: str) -> float:
        """Evaluate Tcl expression *s* and return result as float.
        (clinic: exprdouble($self, s: str, /) -> float)
        """
        raw = self._eval("expr " + _tkinter_wasm_quote("double(" + str(s) + ")"))
        try:
            return float(raw)
        except ValueError:
            raise TclError(f"expression result is not a float: {raw!r}") from None

    def exprboolean(self, s: str) -> int:
        """Evaluate Tcl expression *s* and return result as int (0 or 1).
        Note: returns int, not bool (matches C: PyLong_FromLong(v)).
        (clinic: exprboolean($self, s: str, /) -> int)
        """
        raw = self._eval("expr {(" + str(s) + ") ? 1 : 0}")
        try:
            return int(raw)
        except ValueError:
            raise TclError(f"expression result is not boolean: {raw!r}") from None

    # ------------------------------------------------------------------
    # List splitting
    # ------------------------------------------------------------------

    def splitlist(self, arg: Any) -> tuple:
        """Split a Tcl list string into a tuple of elements.
        (clinic: splitlist($self, arg: object, /) -> tuple)

        PORTING NOTE: The C module has two element-type paths:
          • str/bytes input  → Tcl_SplitList → unicodeFromTclString per element
                               → each element is plain str (not Tcl_Obj)
          • PyTclObject input → Tcl_ListObjGetElements → FromObj per element
                               → typed Python objects

        The WASM bridge always provides string input (via the JS splitlist
        helper), so we always return plain str elements, matching the C
        module's string-input path.  The Tcl_Obj input path is handled by
        extracting .string first and then treating it as a string.
        """
        if isinstance(arg, tuple):
            return arg
        if isinstance(arg, list):
            return tuple(arg)

        if isinstance(arg, Tcl_Obj):
            s = arg.string
        elif isinstance(arg, bytes):
            s = arg.decode("utf-8")
        elif isinstance(arg, str):
            s = arg
        else:
            raise TclError(f"splitlist: unsupported type {type(arg).__name__!r}")

        if not s.strip():
            return ()

        try:
            js_array = _tkinter_wasm.splitlist(s)
        except Exception as exc:
            raise TclError(str(exc)) from None

        # js_array is a Pyodide JsProxy for a JS Array; convert to Python tuple.
        result = []
        for item in js_array:
            result.append(str(item))
        return tuple(result)

    # ------------------------------------------------------------------
    # Command management
    # ------------------------------------------------------------------

    def createcommand(self, name: str, func: Callable) -> None:
        """Register Python callable *func* as Tcl command *name*.
        (clinic: createcommand($self, name: str, func: object, /) FASTCALL 2-args)

        PORTING NOTE (return value): In the C module, PythonCmd() sets the
        Tcl command result via Tcl_SetObjResult(interp, AsObj(res)) so that
        the Tcl caller sees the Python function's return value synchronously.
        In the WASM port, Python callbacks are called asynchronously via
        drainCallbacks() *after* the Tcl command proc has already returned.
        The Tcl proc therefore always returns "" to its caller.

        Impact: event bindings that rely on the Python callback returning
        "break" to stop event propagation (the `if {"[funcid args]" == "break"}
        break` pattern generated by _bind) will not propagate the break.  For
        most widget bindings this is harmless; the callback fires correctly,
        but keyboard/mouse event capture/stop patterns won't work.

        PORTING TODO: Implement synchronous callback dispatch to support
        "break" returns.  Requires either:
          • A re-entrant TkBrowserEval call (currently crashes due to ASYNCIFY),
          • A Pyodide/Emscripten asyncify stack-size fix, or
          • Rewriting _bind to use a polling-based approach.
        """
        if not callable(func):
            raise TypeError(f"createcommand: func must be callable, got {type(func).__name__!r}")
        name = str(name)
        self._commands[name] = func
        # TKINTER-WASM: Wrap the Python callable in a persistent PyProxy.
        # Pyodide auto-destroys borrowed proxies at the end of the JS call,
        # so the stored proxy would be invalid by the time the Tcl command
        # fires.  create_proxy() keeps it alive until we .destroy() it.
        proxy = _tkinter_wasm_create_proxy(func)
        self._command_proxies[name] = proxy
        _tkinter_wasm.createcommand(name, proxy)

    def deletecommand(self, name: str) -> None:
        """Remove the Tcl command named *name*.
        (clinic: deletecommand($self, name: str, /) METH_O)
        """
        name = str(name)
        self._commands.pop(name, None)
        # TKINTER-WASM: destroy the persistent proxy to free Pyodide memory.
        proxy = self._command_proxies.pop(name, None)
        _tkinter_wasm_destroy_proxy(proxy)
        _tkinter_wasm.deletecommand(name)

    # ------------------------------------------------------------------
    # File handlers (not available in WASM)
    # ------------------------------------------------------------------

    def createfilehandler(self, file: Any, mask: int, func: Callable) -> None:
        """Not available on WASM (no real file descriptors).
        (clinic: createfilehandler — Unix only, HAVE_CREATEFILEHANDLER)

        PORTING NOTE: Raises NotImplementedError rather than OSError so that
        callers can cleanly detect the missing capability.
        """
        # PORTING TODO: implement if asyncio/selectors integration is needed.
        raise NotImplementedError(
            "createfilehandler is not supported in the WASM port"
        )

    def deletefilehandler(self, file: Any) -> None:
        """Not available on WASM.
        (clinic: deletefilehandler — Unix only)
        """
        # PORTING TODO: implement if asyncio/selectors integration is needed.
        raise NotImplementedError(
            "deletefilehandler is not supported in the WASM port"
        )

    # ------------------------------------------------------------------
    # Timer handler
    # ------------------------------------------------------------------

    def createtimerhandler(self, milliseconds: int, func: Callable) -> tktimertoken:
        """Schedule *func* to be called after *milliseconds* ms.
        Returns a tktimertoken whose .deletetimerhandler() can cancel it.
        (clinic: createtimerhandler($self, milliseconds: int, func, /) FASTCALL 2-args)
        """
        # TKINTER-WASM: We use Tcl's [after] command to schedule the callback.
        # The callback is registered as a temporary Tcl command that fires once,
        # calls the Python function via drainCallbacks(), and then unregisters
        # itself.
        import random
        token_name = f"::_tkinter_wasm::timer_{random.randrange(2**32):08x}"

        def _timer_callback(*_args: Any) -> None:  # TKINTER-WASM
            # Remove from registry after first call (one-shot timer).
            self._commands.pop(token_name, None)
            # TKINTER-WASM: destroy the proxy now that the timer has fired.
            proxy = self._command_proxies.pop(token_name, None)
            _tkinter_wasm_destroy_proxy(proxy)
            try:
                func()
            except Exception:
                pass  # PORTING TODO: route to tkinter's report_callback_exception

        self._commands[token_name] = _timer_callback
        # TKINTER-WASM: wrap in persistent proxy (same as createcommand).
        proxy = _tkinter_wasm_create_proxy(_timer_callback)
        self._command_proxies[token_name] = proxy
        _tkinter_wasm.createcommand(token_name, proxy)
        self._eval(
            "after " + str(int(milliseconds)) + " " + _tkinter_wasm_quote(token_name)
        )
        # PORTING NOTE: We don't have a real Tcl timer token to cancel;
        # we return a tktimertoken with a synthetic id.  deletetimerhandler()
        # cancels the Tcl [after] by name using [after cancel].
        # PORTING TODO: capture the real after-id returned by [after] and use
        # it in deletetimerhandler for accurate cancellation.
        class _TclTimerToken(tktimertoken):  # TKINTER-WASM
            def __init__(self, cmd_name: str, app: "tkapp") -> None:
                super().__init__(cmd_name)
                self._cmd_name = cmd_name
                self._app = app

            def deletetimerhandler(self) -> None:
                if not self._cancelled:
                    self._cancelled = True
                    try:
                        self._app._eval(
                            "after cancel " + _tkinter_wasm_quote(self._cmd_name)
                        )
                    except TclError:
                        pass
                    self._app.deletecommand(self._cmd_name)

        return _TclTimerToken(token_name, self)

    # ------------------------------------------------------------------
    # Event loop
    # ------------------------------------------------------------------

    def mainloop(self, threshold: int = 0) -> None:
        """Run the Tcl event loop until all main windows are gone (or quit()).

        PORTING NOTE: In the C module this is a blocking loop:
            while (Tk_GetNumMainWindows() > threshold && !quitMainLoop)
                Tcl_DoOneEvent(0)
        In the WASM port, pyodide.runPythonAsync() is used to run Python code.
        Calling time.sleep() inside it yields control back to the JS event
        loop (via Pyodide's asyncio integration) without freezing the browser
        tab.  This allows the Emscripten requestAnimationFrame loop (which
        drives tcltk.wasm's Tcl/Tk event processing) to run between ticks.
        Any callbacks queued by the Emscripten loop during the sleep are
        delivered on the next mainloop tick.
        (clinic: mainloop($self, threshold: int = 0, /) FASTCALL 0-1 args)
        """
        import time
        import js as _js
        global _tkinter_wasm_quit_main_loop

        # Reset the quit flag on entry, matching the C behaviour:
        # quitMainLoop = 0 at start, and again at end of mainloop.
        _tkinter_wasm_quit_main_loop = False

        # TKINTER-WASM: poll interval in seconds.  16 ms ≈ one 60 fps frame,
        # matching the cadence of the Emscripten BrowserEventLoop.  This
        # keeps UI responsive without burning CPU.
        _POLL_INTERVAL = 0.016

        # TKINTER-WASM: Safari does not support Atomics.waitAsync, which
        # Pyodide uses to implement time.sleep() in async contexts.  On
        # Safari we therefore drive ticks via requestAnimationFrame instead
        # of a sleep loop: schedule _do_one_tick() as an rAF callback and
        # return immediately, letting the browser's own frame loop take over.
        _ua = str(_js.window.navigator.userAgent)
        _is_edge    = bool(_js.RegExp.new(r"Edge").test(_ua))
        _is_safari  = bool(_js.RegExp.new(r"safari", "i").test(_ua)) and not _is_edge
        _USE_RAF    = _is_safari

        def _do_one_tick() -> bool:
            """Run one iteration of the mainloop; return False to stop looping."""
            if _tkinter_wasm_quit_main_loop:
                return False
            # Check whether the application window still exists.
            # Mirrors C's Tk_GetNumMainWindows() > threshold check.
            # TKINTER-WASM: we count all children of the Tcl root (.) as
            # "main windows".  In our setup, the Tk app window is always a
            # direct child toplevel of . (named ._tkinter_wasm_tk_<id>).
            # winfo children . lists only currently-existing windows, so
            # a separate winfo exists check is unnecessary.
            try:
                children_str = _tkinter_wasm_eval("winfo children .")
                num_main = len([c for c in children_str.split() if c])
            except TclError:
                num_main = 0
            if num_main <= threshold:
                return False
            # Drain Python callbacks queued by Tcl (button clicks, bindings,
            # variable traces, after-timers, etc.).
            _tkinter_wasm.drainCallbacks()
            # Pump Tcl/X11 events once so that the Emscripten side processes
            # any pending browser UI events (expose, configure, etc.).
            _tkinter_wasm.serviceEvents()
            return True

        if _USE_RAF:
            # TKINTER-WASM: Safari path — schedule ticks via
            # requestAnimationFrame and return immediately so the caller is
            # not blocked.  Each rAF callback reschedules itself as long as
            # _do_one_tick() returns True.
            def _raf_tick(_timestamp):
                if _do_one_tick():
                    _js.window.requestAnimationFrame(_raf_tick)
                else:
                    global _tkinter_wasm_quit_main_loop
                    _tkinter_wasm_quit_main_loop = False

            _js.window.requestAnimationFrame(_raf_tick)
        else:
            while _do_one_tick():
                # Yield to the JS event loop so the Emscripten BrowserEventLoop
                # (requestAnimationFrame) can run Tcl's own event processing.
                # Any callbacks fired by the Emscripten loop during the sleep
                # are accumulated in cbQueue and delivered on the next tick.
                time.sleep(_POLL_INTERVAL)

            _tkinter_wasm_quit_main_loop = False

    def dooneevent(self, flags: int = 0) -> int:
        """Process pending Tcl events; return 1 if any event was handled, 0 otherwise.

        PORTING NOTE: The C module calls Tcl_DoOneEvent(flags) once and
        returns its result (1 = event processed, 0 = none pending,
        -1 = quit requested).  In the WASM port, Tcl event processing is
        driven by the Emscripten BrowserEventLoop (requestAnimationFrame);
        we cannot block here.  Instead we service browser events once and
        drain any pending Python callbacks.

        If DONT_WAIT is not set (flags == 0, the default used by update()),
        we sleep briefly to give the Emscripten loop a chance to process
        events before draining.  This is sufficient for update() / mainloop()
        calls from user code.
        (clinic: dooneevent($self, flags: int = 0, /) FASTCALL 0-1 args)
        """
        import time
        _tkinter_wasm.serviceEvents()
        if not (flags & DONT_WAIT):
            # No DONT_WAIT: yield briefly so the Emscripten BrowserEventLoop
            # can fire and process any pending Tcl events (expose, timers,
            # etc.) before we drain Python callbacks.  Mirrors the C path
            # where Tcl_DoOneEvent(0) blocks until an event arrives.
            # TKINTER-WASM: a short sleep (one rAF frame ≈ 16 ms) is enough.
            time.sleep(0.016)
            _tkinter_wasm.serviceEvents()
        count = _tkinter_wasm.drainCallbacks()
        return 1 if count > 0 else 0

    def quit(self) -> None:
        """Signal the mainloop to exit.
        (Tkapp_Quit: sets quitMainLoop = 1; METH_NOARGS)

        PORTING NOTE: In the C module this sets the module-level static int
        quitMainLoop = 1, which the mainloop() while-loop checks on every
        iteration.  This port now faithfully replicates that behaviour using
        the module-level _tkinter_wasm_quit_main_loop flag.
        """
        global _tkinter_wasm_quit_main_loop
        _tkinter_wasm_quit_main_loop = True

    # ------------------------------------------------------------------
    # Interpreter introspection / control
    # ------------------------------------------------------------------

    def interpaddr(self) -> int:
        """Return the address of the underlying Tcl_Interp * as an int.
        (clinic: interpaddr($self, /) METH_NOARGS)

        PORTING NOTE: Not meaningful in WASM (no direct memory access from
        Python).  Returns 0 rather than raising so that extension modules
        that call this for informational purposes don't crash.
        """
        return 0  # PORTING TODO: expose real WASM pointer if needed

    def loadtk(self) -> None:
        """Call Tk_Init() to load the Tk library into this interpreter.
        (clinic: loadtk($self, /) METH_NOARGS)

        PORTING NOTE: tcltk.wasm initialises both Tcl and Tk in main() before
        any Python code runs.  This is a no-op here; Tk is always loaded.
        """
        pass  # Already done by tcltk.wasm main()

    def wantobjects(self, value: int = None) -> int | None:  # type: ignore[assignment]
        """Get or set the wantobjects flag.
        (Tkapp_WantObjects, METH_VARARGS, format "|i")
        """
        if value is None:
            return self._wantobjects
        self._wantobjects = int(value)
        return None

    # ------------------------------------------------------------------
    # Tracing
    # ------------------------------------------------------------------

    def settrace(self, func: Callable | None) -> None:
        """Set the tracing function (called for every Tcl command executed).
        (clinic: settrace($self, func: object, /) METH_O)
        """
        self._trace_func = func if callable(func) else None

    def gettrace(self) -> Callable | None:
        """Return the current tracing function, or None.
        (clinic: gettrace($self, /) METH_NOARGS)
        """
        return self._trace_func

    def willdispatch(self) -> None:
        """Mark this interpreter as willing to dispatch events.
        (clinic: willdispatch($self, /) METH_NOARGS)

        PORTING NOTE: In the C module sets self->dispatching = 1.  No-op here
        since the WASM event loop handles dispatch independently.
        """
        pass


TkappType = tkapp


# ---------------------------------------------------------------------------
# Module-level functions
# ---------------------------------------------------------------------------

def _flatten(item: Any) -> tuple:
    """Recursively flatten a nested sequence into a flat tuple, skipping None.
    (_tkinter._flatten, METH_O)

    PORTING NOTE: The C module provides a faster compiled version; this is a
    pure-Python equivalent that produces identical results.
    """
    res: list = []
    if isinstance(item, (list, tuple)):
        for x in item:
            if isinstance(x, (list, tuple)):
                res.extend(_flatten(x))
            elif x is not None:
                res.append(x)
    elif item is not None:
        res.append(item)
    return tuple(res)


def create(
    screenName: str | None = None,
    baseName: str = "",
    className: str = "Tk",
    interactive: bool = False,
    wantobjects: int = 0,
    wantTk: bool = True,
    sync: bool = False,
    use: str | None = None,
) -> tkapp:
    """Create a new Tcl/Tk interpreter and return a tkapp object.

    (_tkinter.create, METH_FASTCALL, 0-8 positional args)

    PORTING NOTE: screenName, sync, and use are X11-specific and are ignored
    in the WASM port.  wantTk=False (pure Tcl, no Tk) is honoured by skipping
    Tk initialisation checks; tcltk.wasm always has Tk available so this only
    affects whether the version sanity-check in Tk.__init__ runs.
    """
    
    app = tkapp(wantobjects=int(wantobjects))

    if wantTk:
        # TKINTER-WASM: We set the
        # tcl_library / tk_library variables so that tkinter/__init__.py's
        # version checks pass.  The variables are already set by main.c, but
        # we confirm them here.
        try:
            app._eval("set tcl_library /lib/tcl8.6")
            app._eval("set tk_library /lib/tk8.6")
        except TclError:
            pass  # non-fatal; the variables may already be set

        # TKINTER-WASM: create tk window as a child of actual tcl/tk root
        # with execution id baked into path
        win_path = _tkinter_wasm.rootWindowPath
        app._eval(
            "toplevel " + win_path + " -class " + _tkinter_wasm_quote(className)
        )

        # TKINTER-WASM: Set a human-readable default title, mirroring what
        # CPython's C _tkinter does on desktop (where Tk uses the app name).
        # Without this the title falls back to winPtr->nameUid, which is the
        # raw window path component (e.g. "_tkinter_wasm_tk_abc123").
        # baseName (derived from sys.argv[0]) is preferred; className ("Tk")
        # is used as a last resort when baseName is absent or empty.
        default_title = baseName if baseName else className
        app._eval(
            "wm title " + win_path + " " + _tkinter_wasm_quote(default_title)
        )

    return app


# ---------------------------------------------------------------------------
# Busy-wait interval (threaded Python only; no-op in WASM)
# ---------------------------------------------------------------------------

_tkinter_wasm_busywait_ms: int = 20  # TKINTER-WASM: default from C source


def setbusywaitinterval(new_val: int) -> None:
    """Set the busy-wait interval (ms).
    (_tkinter.setbusywaitinterval, METH_O, int arg)

    PORTING NOTE: The C module uses this to throttle Tcl_DoOneEvent polling
    in a multi-threaded Python process.  WASM is single-threaded; this is a
    no-op that stores the value for completeness.
    """
    global _tkinter_wasm_busywait_ms
    _tkinter_wasm_busywait_ms = int(new_val)


def getbusywaitinterval() -> int:
    """Return the current busy-wait interval in milliseconds.
    (_tkinter.getbusywaitinterval, METH_NOARGS, returns int)
    """
    return _tkinter_wasm_busywait_ms
