# base class for tk common dialogues
#
# this module provides a base class for accessing the common
# dialogues available in Tk 4.2 and newer.  use filedialog,
# colorchooser, and messagebox to access the individual
# dialogs.
#
# written by Fredrik Lundh, May 1997
#

__all__ = ["Dialog"]

from tkinter import _get_temp_root, _destroy_temp_root


class Dialog:

    command = None

    def __init__(self, master=None, **options):
        if master is None:
            master = options.get('parent')
        self.master = master
        self.options = options

    def _fixoptions(self):
        pass # hook

    def _fixresult(self, widget, result):
        return result # hook

    def show(self, **options):

        # update instance options
        for k, v in options.items():
            self.options[k] = v

        self._fixoptions()

        master = self.master
        if master is None:
            master = _get_temp_root()
        try:
            self._test_callback(master)  # The function below is replaced for some tests.
            # TKINTER-WASM PATCH ----------------------------------------------

            # s = master.tk.call(self.command, *master._options(self.options))
            # s = self._fixresult(master, s)


            command = self.command
            options = master._options(self.options)

            if command == "tk_messageBox":
                # Parse flat options tuple: ('-icon', 'error', '-type', 'ok', ...)
                opts = {}
                it = iter(options)
                for key in it:
                    val = next(it, None)
                    opts[str(key).lstrip('-')] = str(val) if val is not None else ""

                icon    = opts.get("icon", "info")
                msgtype = opts.get("type", "ok")
                title   = opts.get("title", "")
                message = opts.get("message", "")

                icon_emoji = {
                    "error":    "❌",
                    "info":     "ℹ️",
                    "question": "❓",
                    "warning":  "⚠️",
                }.get(icon, "💬")

                display = f"{icon_emoji} {title}\n\n{message}" if title else f"{icon_emoji} {message}"

                import js

                if msgtype == "ok":
                    js.window.alert(display)
                    s = "ok"
                elif msgtype == "okcancel":
                    result = js.window.confirm(display)
                    s = "ok" if result else "cancel"
                elif msgtype == "yesno":
                    result = js.window.confirm(display)
                    s = "yes" if result else "no"
                elif msgtype == "yesnocancel":
                    # browsers have no 3-button dialog; confirm maps yes/no,
                    # cancel is not distinguishable — degrade to yes/no
                    result = js.window.confirm(display)
                    s = "yes" if result else "no"
                elif msgtype == "retrycancel":
                    result = js.window.confirm(f"{display}\n\n[OK = Retry / Cancel]")
                    s = "retry" if result else "cancel"
                elif msgtype == "abortretryignore":
                    # no native 3-button dialog; map confirm to retry/abort
                    result = js.window.confirm(f"{display}\n\n[OK = Retry / Cancel = Abort]")
                    s = "retry" if result else "abort"
                else:
                    # graceful degradation for unknown types
                    js.window.alert(display)
                    s = "ok"

            # TKINTER-WASM PATCH ----------------------------------------------
        finally:
            _destroy_temp_root(master)

        return s

    def _test_callback(self, master):
        pass
